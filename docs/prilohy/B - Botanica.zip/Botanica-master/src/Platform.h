#pragma once

class Platform
{
public:
    static double GetTimeSec();
};